import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root'})
export class AnchorService {
  anchors: [];

  constructor() { }

  getAnchors() {
    return new Promise((resolve: ({ }) => void, reject) => {
      fetch('./assets/data.json').then(res => res.json())
        .then((data) => {
          this.anchors = data.properties;
          resolve(this.anchors);
        }, err => {
          console.log(err);
          reject();
        });
    });
  }

  getAnchor(id: string) {
    return new Promise((resolve: ({ }) => void, reject) => {
      this.anchors.filter((row: any, index: number) => {
        if (row.id === id) {
          resolve(row);
        }
        if (this.anchors.length === index + 1) {
          reject();
        }
      });
    });
  }

}