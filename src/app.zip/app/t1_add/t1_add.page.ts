import { Component } from '@angular/core';
import * as Leaflet from 'leaflet';
import { Geolocation } from '@capacitor/geolocation';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-t1_add',
  templateUrl: 't1_add.page.html',
  styleUrls: ['t1_add.page.scss']
})
export class T1_addPage{
  map1: Leaflet.Map;

  constructor() {}
 ionViewDidEnter() {

  this.cargar();

}
cargar(){
  if (this.map1) {
    this.map1.remove();
  }
  this.leafletMap();
  // his.getData();
} 




  leafletMap() {

     var greenIcon = Leaflet.icon({
    iconUrl: 'assets/icon/mark.png',
     iconSize:     [50, 50],  // size of the icon
     iconAnchor:   [25, 50] // point of the icon which will correspond to marker's location});
     });

    this.map1 = Leaflet.map('mapId').setView([41.50053239592097,2.111917734146118], 20);
    Leaflet.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: 'uab.cat | © Angular LeafLet',
    }).addTo(this.map1);
  }


}
 
