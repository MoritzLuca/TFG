import { Component } from '@angular/core';

@Component({
  selector: 'app-t1_anchor',
  templateUrl: 't1_anchor.page.html',
  styleUrls: ['t1_anchor.page.scss']
})
export class T1_anchorPage {

  constructor() {}

}
