import { Component } from '@angular/core';

@Component({
  selector: 'app-t1_ocup',
  templateUrl: 't1_ocup.page.html',
  styleUrls: ['t1_ocup.page.scss']
})
export class T1_ocupPage {

  constructor() {}

}
