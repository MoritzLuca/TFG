import { Component } from '@angular/core';

@Component({
  selector: 'app-t1_report',
  templateUrl: 't1_report.page.html',
  styleUrls: ['t1_report.page.scss']
})
export class T1_reportPage {

  constructor() {}

}
