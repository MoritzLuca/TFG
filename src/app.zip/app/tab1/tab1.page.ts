import { Component } from '@angular/core';
import * as Leaflet from 'leaflet';
import { Geolocation } from '@capacitor/geolocation';
import { AlertController } from '@ionic/angular';



@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  map: Leaflet.Map;
  propertyList = [];

  constructor(public alertCtrl: AlertController) { }

  ionViewDidEnter() {

    this.cargar();
  }
  cargar(){
    if (this.map) {
      this.map.remove();
    }
    this.loadmap();
  }
  loadmap(){
  	this.map = new Leaflet.Map('mapId4').fitWorld();
    Leaflet.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: 'uab.cat'
    }).addTo(this.map);
    var blueIcon = Leaflet.icon({
     iconUrl: 'assets/icon/userLoc.png',
     iconSize:     [50, 50],  // size of the icon
     iconAnchor:   [25, 50] // point of the icon which will correspond to marker's location});
     });

	this.map.locate({
	  setView: true,
	  maxZoom: 10
	  }).on('locationfound', (e) => {
	  let markerGroup = Leaflet.featureGroup();
	  let marker: any = Leaflet.marker([e.latitude, e.longitude], {icon: blueIcon}).on('click', () => {
	  alert('I am Here!');
	  })
	  markerGroup.addLayer(marker);
	  this.map.addLayer(markerGroup);
	  this.map.setZoom(15);
	  }).on('locationerror', (err) => {
    this.map.setView([41.50053239592097,2.111917734146118], 15);    
    //alert(err.message);
        

	  })
    fetch('./assets/data.json')
      .then(res => res.json())
      .then(data => {
        this.propertyList = data.properties;
        this.leafletMap();
      })
      .catch(err => console.error(err));
	}  
  leafletMap() {

    var redIcon = Leaflet.icon({
     iconUrl: 'assets/icon/mark3.png',
     iconSize:     [50, 50],  // size of the icon
     iconAnchor:   [25, 50] // point of the icon which will correspond to marker's location});
     });

    for (const property of this.propertyList) {
      Leaflet.marker([property.lat, property.long], {icon: redIcon}).addTo(this.map)
        .on('click', function(e) {
          var pagebutton=document.getElementById("selfclick");
          pagebutton.click();
        })
    }
  }

}


